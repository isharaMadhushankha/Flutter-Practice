![DP Education IT Campus](https://dpeducation.lk/en/assets/images/brands/en/it-campus.png)

# WORKOUT PLANNER - Application 05 ⚡️

## Overview

This is the 6th Flutter application that we are going to build in the Flutter Development Course at DP Education IT Campus. This application is a workout planner application that allows users to add their workouts and track their progress. Here we dive deep into the concept of state and statefull widgets in Flutter. And working with the local data in Flutter.

## What you will create

![Finished App](https://github.com/HGSChandeepa/Workout-Planner--06---DP-Education/blob/main/assets/app_images/app6.png)

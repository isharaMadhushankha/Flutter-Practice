package com.example.app_06_workout_planer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

const double kDefaultPadding = 10.0;
